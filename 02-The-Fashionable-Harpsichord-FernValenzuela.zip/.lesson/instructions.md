# Instructions  
Please recreate this page to look like this sample:

![Harpsichord sample](assets/HarpsichordSample.jpeg)